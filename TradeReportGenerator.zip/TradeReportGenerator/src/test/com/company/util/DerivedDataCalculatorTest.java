package test.com.company.util;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.company.model.TradeData;
import com.company.util.DataConstants.CurrencyCode;
import com.company.util.DataConstants.Entity;
import com.company.util.DataConstants.TransactionFlag;
import com.company.util.DateUtils;
import com.company.util.DerivedDataCalculator;

public class DerivedDataCalculatorTest {
	
	private TradeData tradeData;
	
	@Before
	public void initializeData() {
		TradeData.Builder builder =  new TradeData.Builder();
		builder.agreedFx(BigDecimal.valueOf(1.0)).entity(Entity.MORGAN_STANLEY).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.EUR).instructionDate(DateUtils.parseDateString("01 Jan 2017")).
		settlementDate(DateUtils.parseDateString("01 Jan 2017")).units(100l).perUnitPrice(new BigDecimal(100.0d)). 
		build();
		tradeData = new TradeData(builder);
		
	}
	
	@Test
	public void testAmendDateIfHolidayWithNullData() {
		LocalDate amendedDate = DerivedDataCalculator.amendDateIfHoliday(null,null);
		Assert.assertNull(amendedDate);
	}
	
	@Test
	public void testAmendDateIfHolidayWithAEDCurrencyAndFriday() {
		LocalDate date = DateUtils.parseDateString("06 Jan 2017");
		LocalDate amendedDate = DerivedDataCalculator.amendDateIfHoliday(date, CurrencyCode.AED);
		Assert.assertEquals("08 Jan 2017", DateUtils.formatDate(amendedDate));
	}
	
	@Test
	public void testAmendDateIfHolidayWithSARCurrencyAndSaturday() {
		LocalDate date = DateUtils.parseDateString("07 Jan 2017");
		LocalDate amendedDate = DerivedDataCalculator.amendDateIfHoliday(date, CurrencyCode.SAR);
		Assert.assertEquals("08 Jan 2017", DateUtils.formatDate(amendedDate));
	}
	
	@Test
	public void testAmendDateIfHolidayWithGBPCurrencyAndFriday() {
		LocalDate date = DateUtils.parseDateString("06 Jan 2017");
		LocalDate amendedDate = DerivedDataCalculator.amendDateIfHoliday(date, CurrencyCode.GBP);
		Assert.assertEquals("06 Jan 2017", DateUtils.formatDate(amendedDate));
	}
	
	@Test
	public void testAmendDateIfHolidayWithSGDCurrencyAndSaturday() {
		LocalDate date = DateUtils.parseDateString("07 Jan 2017");
		LocalDate amendedDate = DerivedDataCalculator.amendDateIfHoliday(date, CurrencyCode.SGD);
		Assert.assertEquals("09 Jan 2017", DateUtils.formatDate(amendedDate));
	}
	
	@Test
	public void testCalculateSettlementAmountInConverionCurrencyWithEURCurrencyCode() {
		BigDecimal tradedAmount = DerivedDataCalculator.calculateSettlementAmountInConverionCurrency(tradeData);
		Assert.assertEquals("10791.565000000001000", tradedAmount.toPlainString());
	}
}
