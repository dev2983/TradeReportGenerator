package test.com.company.util;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import org.junit.Assert;
import org.junit.Test;

import com.company.util.DataConstants.CurrencyCode;
import com.company.util.DateUtils;

public class DateUtilsTest {

	
	@Test
	public void testNullDateString() {
		Assert.assertNull(DateUtils.parseDateString(null));
	}
	
	@Test
	public void testEmptyDateString() {
		Assert.assertNull(DateUtils.parseDateString(""));
	}
	
	@Test
	public void testValidDateString() {
		LocalDate date = DateUtils.parseDateString("01 Jan 2017");
		Assert.assertNotNull(date);
		Assert.assertEquals(2017,date.getYear());
	}
	
	@Test(expected=DateTimeParseException.class)
	public void testInValidDateString() {
		LocalDate date = DateUtils.parseDateString("01-01-2017");
		Assert.assertNull(date);
	}
	
	@Test
	public void testNullFormatDate() {
		String dateFormattedString = DateUtils.formatDate(null); 
		Assert.assertNull(dateFormattedString);
	}
	
	@Test
	public void testValidFormatDate() {
		String dateFormattedString = DateUtils.formatDate(LocalDate.of(2016,11,21)); 
		Assert.assertEquals("21 Nov 2016", dateFormattedString);;
	}
	
}
