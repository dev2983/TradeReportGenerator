package test.com.company.handler;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.company.handler.TradeDataHandler;
import com.company.model.Pair;
import com.company.model.TradeData;
import com.company.util.DataConstants.CurrencyCode;
import com.company.util.DataConstants.Entity;
import com.company.util.DataConstants.TransactionFlag;
import com.company.util.DateUtils;


public class TradeDataHandlerTest {
	
	
	private TradeDataHandler handler = new TradeDataHandler();
	private static TradeData tradeData1;
	private static TradeData tradeData2;
	private static TradeData tradeData3;
	private static TradeData tradeData4;
	private static TradeData tradeData5;
	private static TradeData tradeData6;
	private static TradeData tradeData7;
	private Map<LocalDate,Pair<BigDecimal,BigDecimal>> amountPairBySettlementDateMap =  new HashMap<>();
	Map<Entity,BigDecimal> buySettlementByEntityAmountMap = new HashMap<>();
	Map<Entity,BigDecimal> sellSettlementByEntityAmountMap = new HashMap<>();
	
	@BeforeClass
	public static void initializeData() {
		
		TradeData.Builder builder =  new TradeData.Builder();
		builder.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.MORGAN_STANLEY).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.EUR).instructionDate(DateUtils.parseDateString("01 Jan 2017")).
		settlementDate(DateUtils.parseDateString("01 Jan 2017")).units(200l).perUnitPrice(new BigDecimal(100.25d)). 
		build();
		tradeData1 = new TradeData(builder);
		
		builder =  new TradeData.Builder();
		builder.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.CITICORP).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.AED).instructionDate(DateUtils.parseDateString("01 Jan 2017")).
		settlementDate(DateUtils.parseDateString("01 Jan 2017")).units(200l).perUnitPrice(new BigDecimal(100.25d)). 
		build();
		tradeData2 = new TradeData(builder);
		
		builder =  new TradeData.Builder();
		builder.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.CITICORP).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.SAR).instructionDate(DateUtils.parseDateString("06 Jan 2017")).
		settlementDate(DateUtils.parseDateString("06 Jan 2017")).units(200l).perUnitPrice(new BigDecimal(100.25d)). 
		build();
		tradeData3 = new TradeData(builder);
		
		builder =  new TradeData.Builder();
		builder.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.MORGAN_STANLEY).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.EUR).instructionDate(DateUtils.parseDateString("01 Jan 2017")).
		settlementDate(DateUtils.parseDateString("01 Jan 2017")).units(200l).perUnitPrice(new BigDecimal(100.00d)). 
		build();
		tradeData4 = new TradeData(builder);
		
		builder =  new TradeData.Builder();
		builder.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.MORGAN_STANLEY).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.EUR).instructionDate(DateUtils.parseDateString("01 Jan 2017")).
		settlementDate(DateUtils.parseDateString("01 Jan 2017")).units(200l).perUnitPrice(new BigDecimal(100.00d)). 
		build();
		tradeData5 = new TradeData(builder);
		
		builder =  new TradeData.Builder();
		builder.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.HSBC).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.EUR).instructionDate(DateUtils.parseDateString("01 Jan 2017")).
		settlementDate(DateUtils.parseDateString("01 Jan 2017")).units(200l).perUnitPrice(new BigDecimal(100.00d)). 
		build();
		tradeData6 = new TradeData(builder);
		
		builder =  new TradeData.Builder();
		builder.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.UBS).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.SAR).instructionDate(DateUtils.parseDateString("06 Jan 2017")).
		settlementDate(DateUtils.parseDateString("06 Jan 2017")).units(200l).perUnitPrice(new BigDecimal(100.25d)). 
		build();
		tradeData7 = new TradeData(builder);
		
	}
	
	
	@Test
	public void testGetTransactionAmountBySettlementDateByEuroAndSunday() {
		handler.getTransactionAmountBySettlementDate(tradeData1, amountPairBySettlementDateMap);
		Assert.assertEquals(1, amountPairBySettlementDateMap.size());
		Object[] key = amountPairBySettlementDateMap.keySet().toArray();
		LocalDate amendedDate = (LocalDate)key[0];
		Assert.assertEquals("02 Jan 2017", DateUtils.formatDate(amendedDate));
		Object[] values = amountPairBySettlementDateMap.values().toArray();
		@SuppressWarnings("unchecked")
		Pair<BigDecimal,BigDecimal> pair = (Pair<BigDecimal,BigDecimal>)values[0];
		Assert.assertNull(pair.getSecond());
		Assert.assertEquals("10818.54391250000150375",pair.getFirst().toString());
		
	}
	
	@Test
	public void testGetTransactionAmountBySettlementDateByAEDAndSunday() {
		handler.getTransactionAmountBySettlementDate(tradeData2, amountPairBySettlementDateMap);
		Assert.assertEquals(1, amountPairBySettlementDateMap.size());
		Object[] key = amountPairBySettlementDateMap.keySet().toArray();
		LocalDate amendedDate = (LocalDate)key[0];
		Assert.assertEquals("01 Jan 2017", DateUtils.formatDate(amendedDate));
		Object[] values = amountPairBySettlementDateMap.values().toArray();
		@SuppressWarnings("unchecked")
		Pair<BigDecimal,BigDecimal> pair = (Pair<BigDecimal,BigDecimal>)values[0];
		Assert.assertNull(pair.getSecond());
		Assert.assertEquals("54536.0000",pair.getFirst().toString());
		
	}
	
	@Test
	public void testGetTransactionAmountBySettlementDateBySARAndFriday() {
		handler.getTransactionAmountBySettlementDate(tradeData3, amountPairBySettlementDateMap);
		Assert.assertEquals(1, amountPairBySettlementDateMap.size());
		Object[] key = amountPairBySettlementDateMap.keySet().toArray();
		LocalDate amendedDate = (LocalDate)key[0];
		Assert.assertEquals("08 Jan 2017", DateUtils.formatDate(amendedDate));
		Object[] values = amountPairBySettlementDateMap.values().toArray();
		@SuppressWarnings("unchecked")
		Pair<BigDecimal,BigDecimal> pair = (Pair<BigDecimal,BigDecimal>)values[0];
		Assert.assertNull(pair.getSecond());
		Assert.assertEquals("15594.5491500",pair.getFirst().toString());
		
	}
	
	@Test
	public void testBuildRankedEntityListBySettlementAmountsForOneEntity() {
		handler.buildSettlementAmountByEntity(tradeData4, buySettlementByEntityAmountMap,sellSettlementByEntityAmountMap);
		handler.buildSettlementAmountByEntity(tradeData5, buySettlementByEntityAmountMap,sellSettlementByEntityAmountMap);
		Assert.assertEquals(1,buySettlementByEntityAmountMap.size());
		Assert.assertEquals(Entity.MORGAN_STANLEY, buySettlementByEntityAmountMap.keySet().iterator().next());
		Assert.assertEquals("10791.565000000001500", buySettlementByEntityAmountMap.values().iterator().next().toString());
	}
	
	@Test
	public void testBuildRankedEntityListBySettlementAmountsForTwoEntity() {
		handler.buildSettlementAmountByEntity(tradeData1, buySettlementByEntityAmountMap,sellSettlementByEntityAmountMap);
		handler.buildSettlementAmountByEntity(tradeData2, buySettlementByEntityAmountMap,sellSettlementByEntityAmountMap);
		handler.buildSettlementAmountByEntity(tradeData3, buySettlementByEntityAmountMap,sellSettlementByEntityAmountMap);
		handler.buildSettlementAmountByEntity(tradeData4, buySettlementByEntityAmountMap,sellSettlementByEntityAmountMap);
		handler.buildSettlementAmountByEntity(tradeData5, buySettlementByEntityAmountMap,sellSettlementByEntityAmountMap);
		handler.buildSettlementAmountByEntity(tradeData6, buySettlementByEntityAmountMap,sellSettlementByEntityAmountMap);
		handler.buildSettlementAmountByEntity(tradeData7, buySettlementByEntityAmountMap,sellSettlementByEntityAmountMap);
		Assert.assertEquals(2,buySettlementByEntityAmountMap.size());
		Assert.assertEquals(2,sellSettlementByEntityAmountMap.size());
		Set<Entity> buyEntitySet = buySettlementByEntityAmountMap.keySet();
		Set<Entity> sellEntitySet = sellSettlementByEntityAmountMap.keySet();
		Assert.assertTrue(buyEntitySet.contains(Entity.MORGAN_STANLEY));
		Assert.assertTrue(buyEntitySet.contains(Entity.CITICORP));
		
		Assert.assertTrue(sellEntitySet.contains(Entity.UBS));
		Assert.assertTrue(sellEntitySet.contains(Entity.HSBC));
	}
}
