package test.com.company.handler;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import com.company.handler.TradeDataAggregationHandler;
import com.company.model.TradeData;
import com.company.model.TradeReport;
import com.company.util.DateUtils;

import org.junit.Assert;

import com.company.util.DataConstants.CurrencyCode;
import com.company.util.DataConstants.Entity;
import com.company.util.DataConstants.TransactionFlag;

public class TradeDataAggregationHandlerTest {
	
	private TradeDataAggregationHandler dataAggregationHandler = new TradeDataAggregationHandler();
	private static List<TradeData> list = null;
	
	@BeforeClass
	public static void setUp() throws Exception {
		
		list = new ArrayList<>();
		TradeData.Builder builder1 =  new TradeData.Builder();
		LocalDate settlementDate1 = DateUtils.parseDateString("01 Jan 2017");//SUN
		builder1.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.MORGAN_STANLEY).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.EUR).instructionDate(settlementDate1).
		settlementDate(settlementDate1).units(200l).perUnitPrice(new BigDecimal(100.25d)). 
		build();
		TradeData tradeData1 = new TradeData(builder1);
		list.add(tradeData1);
		
		TradeData.Builder builder2 =  new TradeData.Builder();
		LocalDate settlementDate2 = DateUtils.parseDateString("01 Jan 2017");//SUN
		builder2.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.CITICORP).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.EUR).instructionDate(settlementDate2).
		settlementDate(settlementDate2).units(200l).perUnitPrice(new BigDecimal(1500.25d)). 
		build();
		TradeData tradeData2 = new TradeData(builder2);
		list.add(tradeData2);
		
		TradeData.Builder builder3 =  new TradeData.Builder();
		LocalDate settlementDate3 = DateUtils.parseDateString("02 Jan 2017");//MON
		builder3.agreedFx(BigDecimal.valueOf(1.5d)).entity(Entity.MORGAN_STANLEY).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.SGD).instructionDate(settlementDate3).
		settlementDate(settlementDate3).units(200l).perUnitPrice(new BigDecimal(100.25d)). 
		build();
		TradeData tradeData3 = new TradeData(builder3);
		list.add(tradeData3);
		
		TradeData.Builder builder4 =  new TradeData.Builder();
		LocalDate settlementDate4 = DateUtils.parseDateString("02 Jan 2017");//MON
		builder4.agreedFx(BigDecimal.valueOf(1.5d)).entity(Entity.CITICORP).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.SGD).instructionDate(settlementDate4).
		settlementDate(settlementDate4).units(200l).perUnitPrice(new BigDecimal(1500.5d)). 
		build();
		TradeData tradeData4 = new TradeData(builder4);
		list.add(tradeData4);
		
	}

	@Test
	public void testAmountPairBySettlementDateMap() {
		TradeReport report = dataAggregationHandler.buildReportData(list);
		Assert.assertEquals(1, report.getAmountPairBySettlementDateMap().size());
		Assert.assertEquals(1, report.getBuySettlementByEntityRankedList().size());
		Assert.assertEquals(2, report.getSellSettlementByEntityRankedList().size());
		Assert.assertEquals(Entity.CITICORP, report.getSellSettlementByEntityRankedList().get(0).getKey());
		Assert.assertEquals(Entity.MORGAN_STANLEY, report.getSellSettlementByEntityRankedList().get(1).getKey());
	}
	
	@Test
	public void testAmountPairBySettlementDateMapWithEmptyTradeDataList() {
		TradeReport report = dataAggregationHandler.buildReportData(new ArrayList<>());
		Assert.assertEquals(0, report.getAmountPairBySettlementDateMap().size());
		Assert.assertEquals(0, report.getBuySettlementByEntityRankedList().size());
		Assert.assertEquals(0, report.getSellSettlementByEntityRankedList().size());
	}

}
