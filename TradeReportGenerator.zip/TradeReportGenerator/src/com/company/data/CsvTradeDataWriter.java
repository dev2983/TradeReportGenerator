package com.company.data;

import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.company.model.TradeData;
import com.company.util.DataConstants.CurrencyCode;
import com.company.util.DataConstants.Entity;
import com.company.util.DataConstants.TransactionFlag;
import com.company.util.DateUtils;

public class CsvTradeDataWriter {

	//Delimiter used in CSV file
	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\n";
	//CSV file header
	private static final String FILE_HEADER = "Entity,Buy/Sell,AgreedFx,Currency,Instruction Date,Settlement Date,Units,Price,per unit";
	public static void main(String[] args) {
		//writeDataToCsvFile(100000,null);//to include both buy and sell records
		writeDataToCsvFile(10000,TransactionFlag.BUY);
	}

	public static void writeDataToCsvFile(int numberOfRecords,TransactionFlag buyOrSell) {
		String buySellFlag = null;
		int countOfTrades = 10;
		if(buyOrSell ==  null) { buySellFlag = "BUY_AND_SELL";countOfTrades =20; }
		else { buySellFlag = buyOrSell.toString(); }
		
		String fileName = new StringBuilder("tradeData_").append(buySellFlag).append("_").append(String.valueOf(numberOfRecords * countOfTrades)).append(".csv").toString() ;
		
		try(FileWriter fileWriter = new FileWriter(fileName);) {
			
			fileWriter.append(FILE_HEADER.toString());
			fileWriter.append(NEW_LINE_SEPARATOR);
			List<TradeData> list = new ArrayList<>(numberOfRecords);
			for(int i=0;i<numberOfRecords;i++) {
				if(TransactionFlag.BUY == buyOrSell || "BUY_AND_SELL".equals(buySellFlag)) { list.addAll(createBuyTradeData(i)); }
				if(TransactionFlag.SELL == buyOrSell || "BUY_AND_SELL".equals(buySellFlag)) { list.addAll(createSellTradeData(i)); }
			}
			for(TradeData data : list) {
				writeTradeDataToFileWriter(fileWriter,data);
			}
			System.out.println("File is created successfully with name : " + fileName);

		} 
		catch (IOException e) {
			System.out.println("Error in CsvFileWriter !!!");
		}

	}
	
	private static void writeTradeDataToFileWriter(FileWriter writer,TradeData tradeData) throws IOException {
		writer.append(tradeData.getEntity().getCode()).append(COMMA_DELIMITER).
		append(tradeData.getTransactionFlag().getCode()).append(COMMA_DELIMITER).
		append(String.valueOf(tradeData.getAgreedFx()) ).append(COMMA_DELIMITER).
		append(tradeData.getCurrencyCode().toString()).append(COMMA_DELIMITER).
		append(DateUtils.formatDate(tradeData.getInstructionDate())).append(COMMA_DELIMITER).
		append(DateUtils.formatDate(tradeData.getSettlementDate())).append(COMMA_DELIMITER).
		append(String.valueOf(tradeData.getUnits())).append(COMMA_DELIMITER).
		append(String.valueOf(tradeData.getPerUnitPrice())).append(NEW_LINE_SEPARATOR);
		
	}
	
	private static List<TradeData> createBuyTradeData(int i) {
		
		List<TradeData> list = new ArrayList<>();
		TradeData.Builder builder1 =  new TradeData.Builder();
		LocalDate settlementDate1 = DateUtils.parseDateString("01 Jan 2017").plusDays(i);//SUN
		builder1.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.MORGAN_STANLEY).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.EUR).instructionDate(settlementDate1).
		settlementDate(settlementDate1).units(200l).perUnitPrice(new BigDecimal(100.25d)). 
		build();
		TradeData tradeData1 = new TradeData(builder1);
		list.add(tradeData1);
		
		TradeData.Builder builder2 =  new TradeData.Builder();
		LocalDate settlementDate2 = DateUtils.parseDateString("01 Jan 2017").plusDays(i);//SUN
		builder2.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.CITICORP).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.EUR).instructionDate(settlementDate2).
		settlementDate(settlementDate2).units(200l).perUnitPrice(new BigDecimal(1500.25d)). 
		build();
		TradeData tradeData2 = new TradeData(builder2);
		list.add(tradeData2);
		
		TradeData.Builder builder3 =  new TradeData.Builder();
		LocalDate settlementDate3 = DateUtils.parseDateString("02 Jan 2017").plusDays(i);//MON
		builder3.agreedFx(BigDecimal.valueOf(1.5d)).entity(Entity.MORGAN_STANLEY).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.SGD).instructionDate(settlementDate3).
		settlementDate(settlementDate3).units(200l).perUnitPrice(new BigDecimal(100.25d)). 
		build();
		TradeData tradeData3 = new TradeData(builder3);
		list.add(tradeData3);
		
		TradeData.Builder builder4 =  new TradeData.Builder();
		LocalDate settlementDate4 = DateUtils.parseDateString("02 Jan 2017").plusDays(i);//MON
		builder4.agreedFx(BigDecimal.valueOf(1.5d)).entity(Entity.CITICORP).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.SGD).instructionDate(settlementDate4).
		settlementDate(settlementDate4).units(200l).perUnitPrice(new BigDecimal(1500.5d)). 
		build();
		TradeData tradeData4 = new TradeData(builder4);
		list.add(tradeData4);
		
		TradeData.Builder builder5 =  new TradeData.Builder();
		LocalDate settlementDate5 = DateUtils.parseDateString("06 Jan 2017").plusDays(i);//FRI
		builder5.agreedFx(BigDecimal.valueOf(0.25d)).entity(Entity.UBS).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.AED).instructionDate(DateUtils.parseDateString("05 Jan 2017")).
		settlementDate(settlementDate5).units(200l).perUnitPrice(new BigDecimal(100.0d)). 
		build();
		TradeData tradeData5 = new TradeData(builder5);
		list.add(tradeData5);
		
		TradeData.Builder builder6 =  new TradeData.Builder();
		LocalDate settlementDate6 = DateUtils.parseDateString("06 Jan 2017").plusDays(i);//FRI
		builder6.agreedFx(BigDecimal.valueOf(0.25d)).entity(Entity.UBS).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.AED).instructionDate(DateUtils.parseDateString("05 Jan 2017")).
		settlementDate(settlementDate6).units(200l).perUnitPrice(new BigDecimal(1500.5d)). 
		build();
		TradeData tradeData6 = new TradeData(builder6);
		list.add(tradeData6);
		
		TradeData.Builder builder7 =  new TradeData.Builder();
		LocalDate settlementDate7 = DateUtils.parseDateString("15 Jan 2017").plusDays(i);//SUN
		builder7.agreedFx(BigDecimal.valueOf(0.25d)).entity(Entity.HSBC).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.SGD).instructionDate(DateUtils.parseDateString("15 Jan 2017")).
		settlementDate(settlementDate7).units(200l).perUnitPrice(new BigDecimal(100.0d)). 
		build();
		TradeData tradeData7 = new TradeData(builder7);
		list.add(tradeData7);
		
		TradeData.Builder builder8 =  new TradeData.Builder();
		LocalDate settlementDate8 = DateUtils.parseDateString("20 Jan 2017").plusDays(i);//FRI
		builder8.agreedFx(BigDecimal.valueOf(0.25d)).entity(Entity.CARGILL).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.AED).instructionDate(DateUtils.parseDateString("20 Jan 2017")).
		settlementDate(settlementDate8).units(200l).perUnitPrice(new BigDecimal(1500.5d)). 
		build();
		TradeData tradeData8 = new TradeData(builder8);
		list.add(tradeData8);
		
		TradeData.Builder builder9 =  new TradeData.Builder();
		LocalDate settlementDate9 = DateUtils.parseDateString("15 Jan 2017").plusDays(i);//SUN
		builder9.agreedFx(BigDecimal.valueOf(0.25d)).entity(Entity.HSBC).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.SGD).instructionDate(DateUtils.parseDateString("15 Jan 2017")).
		settlementDate(settlementDate9).units(200l).perUnitPrice(new BigDecimal(100.0d)). 
		build();
		TradeData tradeData9 = new TradeData(builder9);
		list.add(tradeData9);
		
		TradeData.Builder builder10 =  new TradeData.Builder();
		LocalDate settlementDate10 = DateUtils.parseDateString("20 Jan 2017").plusDays(i);//FRI
		builder10.agreedFx(BigDecimal.valueOf(0.25d)).entity(Entity.CARGILL).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.SAR).instructionDate(DateUtils.parseDateString("20 Jan 2017")).
		settlementDate(settlementDate10).units(200l).perUnitPrice(new BigDecimal(1500.5d)). 
		build();
		TradeData tradeData10 = new TradeData(builder10);
		list.add(tradeData10);
		
		return list;
	}
	
	private static List<TradeData> createSellTradeData(int i) {
		
		List<TradeData> list = new ArrayList<>();
		TradeData.Builder builder1 =  new TradeData.Builder();
		LocalDate settlementDate1 = DateUtils.parseDateString("01 Jan 2017").plusDays(i);//SUN
		builder1.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.MORGAN_STANLEY).transactionFlag(TransactionFlag.BUY).
		currencyCode(CurrencyCode.EUR).instructionDate(settlementDate1).
		settlementDate(settlementDate1).units(200l).perUnitPrice(new BigDecimal(100.25d)). 
		build();
		TradeData tradeData1 = new TradeData(builder1);
		list.add(tradeData1);
		
		TradeData.Builder builder2 =  new TradeData.Builder();
		LocalDate settlementDate2 = DateUtils.parseDateString("01 Jan 2017").plusDays(i);//SUN
		builder2.agreedFx(BigDecimal.valueOf(0.5d)).entity(Entity.CITICORP).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.EUR).instructionDate(settlementDate2).
		settlementDate(settlementDate2).units(200l).perUnitPrice(new BigDecimal(1500.25d)). 
		build();
		TradeData tradeData2 = new TradeData(builder2);
		list.add(tradeData2);
		
		TradeData.Builder builder3 =  new TradeData.Builder();
		LocalDate settlementDate3 = DateUtils.parseDateString("02 Jan 2017").plusDays(i);//MON
		builder3.agreedFx(BigDecimal.valueOf(1.5d)).entity(Entity.MORGAN_STANLEY).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.SGD).instructionDate(settlementDate3).
		settlementDate(settlementDate3).units(200l).perUnitPrice(new BigDecimal(100.25d)). 
		build();
		TradeData tradeData3 = new TradeData(builder3);
		list.add(tradeData3);
		
		TradeData.Builder builder4 =  new TradeData.Builder();
		LocalDate settlementDate4 = DateUtils.parseDateString("02 Jan 2017").plusDays(i);//MON
		builder4.agreedFx(BigDecimal.valueOf(1.5d)).entity(Entity.CITICORP).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.SGD).instructionDate(settlementDate4).
		settlementDate(settlementDate4).units(200l).perUnitPrice(new BigDecimal(1500.5d)). 
		build();
		TradeData tradeData4 = new TradeData(builder4);
		list.add(tradeData4);
		
		TradeData.Builder builder5 =  new TradeData.Builder();
		LocalDate settlementDate5 = DateUtils.parseDateString("06 Jan 2017").plusDays(i);//FRI
		builder5.agreedFx(BigDecimal.valueOf(0.25d)).entity(Entity.UBS).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.AED).instructionDate(DateUtils.parseDateString("05 Jan 2017")).
		settlementDate(settlementDate5).units(200l).perUnitPrice(new BigDecimal(100.0d)). 
		build();
		TradeData tradeData5 = new TradeData(builder5);
		list.add(tradeData5);
		
		TradeData.Builder builder6 =  new TradeData.Builder();
		LocalDate settlementDate6 = DateUtils.parseDateString("06 Jan 2017").plusDays(i);//FRI
		builder6.agreedFx(BigDecimal.valueOf(0.25d)).entity(Entity.UBS).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.AED).instructionDate(DateUtils.parseDateString("05 Jan 2017")).
		settlementDate(settlementDate6).units(200l).perUnitPrice(new BigDecimal(1500.5d)). 
		build();
		TradeData tradeData6 = new TradeData(builder6);
		list.add(tradeData6);
		
		TradeData.Builder builder7 =  new TradeData.Builder();
		LocalDate settlementDate7 = DateUtils.parseDateString("15 Jan 2017").plusDays(i);//SUN
		builder7.agreedFx(BigDecimal.valueOf(0.25d)).entity(Entity.HSBC).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.SGD).instructionDate(DateUtils.parseDateString("15 Jan 2017")).
		settlementDate(settlementDate7).units(200l).perUnitPrice(new BigDecimal(100.0d)). 
		build();
		TradeData tradeData7 = new TradeData(builder7);
		list.add(tradeData7);
		
		TradeData.Builder builder8 =  new TradeData.Builder();
		LocalDate settlementDate8 = DateUtils.parseDateString("20 Jan 2017").plusDays(i);//FRI
		builder8.agreedFx(BigDecimal.valueOf(0.25d)).entity(Entity.CARGILL).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.AED).instructionDate(DateUtils.parseDateString("20 Jan 2017")).
		settlementDate(settlementDate8).units(200l).perUnitPrice(new BigDecimal(1500.5d)). 
		build();
		TradeData tradeData8 = new TradeData(builder8);
		list.add(tradeData8);
		
		TradeData.Builder builder9 =  new TradeData.Builder();
		LocalDate settlementDate9 = DateUtils.parseDateString("15 Jan 2017").plusDays(i);//SUN
		builder9.agreedFx(BigDecimal.valueOf(0.25d)).entity(Entity.HSBC).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.SGD).instructionDate(DateUtils.parseDateString("15 Jan 2017")).
		settlementDate(settlementDate9).units(200l).perUnitPrice(new BigDecimal(100.0d)). 
		build();
		TradeData tradeData9 = new TradeData(builder9);
		list.add(tradeData9);
		
		TradeData.Builder builder10 =  new TradeData.Builder();
		LocalDate settlementDate10 = DateUtils.parseDateString("20 Jan 2017").plusDays(i);//FRI
		builder10.agreedFx(BigDecimal.valueOf(0.25d)).entity(Entity.CARGILL).transactionFlag(TransactionFlag.SELL).
		currencyCode(CurrencyCode.SAR).instructionDate(DateUtils.parseDateString("20 Jan 2017")).
		settlementDate(settlementDate10).units(200l).perUnitPrice(new BigDecimal(1500.5d)). 
		build();
		TradeData tradeData10 = new TradeData(builder10);
		list.add(tradeData10);
		return list;
	}

}
