package com.company.data;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.company.model.TradeData;
import com.company.util.DataConstants.CurrencyCode;
import com.company.util.DataConstants.Entity;
import com.company.util.DataConstants.TransactionFlag;
import com.company.util.DateUtils;

public class CsvTradeDataReader {
	
	public List<TradeData> loadTradeDataList(String csvFileName) {

		String line = "";
		String cvsDelimiter = ",";
		List<TradeData> tradeDataList = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader(csvFileName))) {
			int count = 0;
			while ((line = br.readLine()) != null) {
				if(count == 0) { 
					count ++; continue; 
				}
				
				// use comma as delimiter
				String[] tradeDataArray = line.split(cvsDelimiter);
				TradeData tradeData = mapArrayToObject(tradeDataArray);
				tradeDataList.add(tradeData);
				//System.out.println("Trade Data = "+ tradeData);

			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return tradeDataList;
	}
	
	private TradeData mapArrayToObject(String[] tradeDataArray) {
		
		TradeData.Builder builder = new TradeData.Builder();
		builder.entity(Entity.getEntityByCode(tradeDataArray[0])).
		transactionFlag(TransactionFlag.getTransactionFlagByCode(tradeDataArray[1])).
		agreedFx(BigDecimal.valueOf(Double.valueOf(tradeDataArray[2]))).currencyCode(CurrencyCode.valueOf(tradeDataArray[3])).
		instructionDate(DateUtils.parseDateString(tradeDataArray[4])).
		settlementDate(DateUtils.parseDateString(tradeDataArray[5])).
		units(Long.valueOf(tradeDataArray[6])).perUnitPrice(new BigDecimal(tradeDataArray[7]));
		TradeData tradeData = builder.build();
		return tradeData;
	}
	
	
}
