package com.company.handler;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;

import com.company.model.DerivedTradeData;
import com.company.model.Pair;
import com.company.model.TradeData;
import com.company.util.DataConstants.Entity;
import com.company.util.DataConstants.TransactionFlag;

public class TradeDataHandler {
	
	public void getTransactionAmountBySettlementDate(TradeData tradeData,Map<LocalDate,Pair<BigDecimal,BigDecimal>> amountPairBySettlementDateMap) {
		
		DerivedTradeData derivedTradeData = tradeData.getDerivedTradeData();
		LocalDate settlementDate = derivedTradeData.getAmendedSettlementDate();
		BigDecimal buyAmount = (TransactionFlag.BUY.equals(tradeData.getTransactionFlag())) ? 
				tradeData.getDerivedTradeData().getConvertedSettlementAmount() : null;
		BigDecimal sellAmount = (TransactionFlag.SELL.equals(tradeData.getTransactionFlag())) ? 
						tradeData.getDerivedTradeData().getConvertedSettlementAmount() : null;

		Pair<BigDecimal,BigDecimal> settlementAmountPair = amountPairBySettlementDateMap.get(settlementDate);
		if(settlementAmountPair == null) {
			settlementAmountPair = new Pair<>(buyAmount,sellAmount);
			amountPairBySettlementDateMap.put(settlementDate, settlementAmountPair);
		}
		else {
			setAmount(settlementAmountPair,buyAmount,sellAmount);
		}
	}
	
	public void buildSettlementAmountByEntity(TradeData tradeData,Map<Entity,BigDecimal> buySettlementByEntityAmountMap,
			Map<Entity,BigDecimal> sellSettlementByEntityAmountMap) {
		
		if(TransactionFlag.BUY.equals(tradeData.getTransactionFlag()) ) {
			setSettlementByEntityAmountMap(tradeData,buySettlementByEntityAmountMap);
		}
		else if(TransactionFlag.SELL.equals(tradeData.getTransactionFlag()) ) {
			setSettlementByEntityAmountMap(tradeData,sellSettlementByEntityAmountMap);
		}
	}
	
	private void setSettlementByEntityAmountMap(TradeData tradeData,Map<Entity,BigDecimal> settlementByEntityAmountMap) {
		BigDecimal convertedTradeSettlementAmount =  tradeData.getDerivedTradeData().getConvertedSettlementAmount();
		if(settlementByEntityAmountMap.get(tradeData.getEntity()) == null) {
			settlementByEntityAmountMap.put(tradeData.getEntity(), convertedTradeSettlementAmount);
		}
		else {
			settlementByEntityAmountMap.get(tradeData.getEntity()).add(convertedTradeSettlementAmount);
		}
	}
	
	private void setAmount(Pair<BigDecimal,BigDecimal> settlementAmountPair,BigDecimal buyAmount,BigDecimal sellAmount) {
		if(settlementAmountPair.getFirst() == null) {
			settlementAmountPair.setFirst(buyAmount);
		}
		else if(buyAmount!=null){
			settlementAmountPair.setFirst(settlementAmountPair.getFirst().add(buyAmount));
		}
		if(settlementAmountPair.getSecond() == null) {
			settlementAmountPair.setSecond(sellAmount);
		}
		else if(sellAmount!=null) {
			settlementAmountPair.setSecond(settlementAmountPair.getSecond().add(sellAmount));
		}
	}	
		
}
