package com.company.handler;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.company.model.Pair;
import com.company.model.TradeData;
import com.company.model.TradeReport;
import com.company.util.DataConstants.Entity;

public class TradeDataAggregationHandler {

	private TradeDataHandler tradeDataHandler;
	private Comparator<Map.Entry<Entity, BigDecimal>> reverseSortBySettlementAmountComparator;
	private Map<LocalDate,Pair<BigDecimal,BigDecimal>> amountPairBySettlementDateMap;

	public TradeDataAggregationHandler() {
		tradeDataHandler =  new TradeDataHandler();
		reverseSortBySettlementAmountComparator = (entry1,entry2) -> entry2.getValue().compareTo(entry1.getValue());
	}

	public Map<LocalDate, Pair<BigDecimal, BigDecimal>> getAmountPairBySettlementDateMap() {
		return amountPairBySettlementDateMap;
	}

	public TradeReport buildReportData(List<TradeData> tradeDataList) {

		amountPairBySettlementDateMap = new HashMap<>(tradeDataList.size());

		Map<Entity,BigDecimal> buySettlementByEntityAmountMap = new HashMap<>(tradeDataList.size());
		Map<Entity,BigDecimal> sellSettlementByEntityAmountMap = new HashMap<>(tradeDataList.size());

		tradeDataList.stream().forEach(tradeData -> { 

			tradeDataHandler.getTransactionAmountBySettlementDate(tradeData,amountPairBySettlementDateMap);
			tradeDataHandler.buildSettlementAmountByEntity(tradeData, buySettlementByEntityAmountMap,sellSettlementByEntityAmountMap);
			//tradeDataHandler.buildSettlementAmountByEntity(tradeData, sellSettlementByEntityAmountMap);
		});

		Pair<List<Entry<Entity,BigDecimal>>, List<Entry<Entity,BigDecimal>>> rankedEntityPair = this.
				buildRankedEntityListBySettlementAmounts(buySettlementByEntityAmountMap,sellSettlementByEntityAmountMap);

		return new TradeReport(amountPairBySettlementDateMap,rankedEntityPair);
	}

	public Pair<List<Entry<Entity,BigDecimal>>, List<Entry<Entity,BigDecimal>>> buildRankedEntityListBySettlementAmounts
																				(Map<Entity,BigDecimal> buySettlementByEntityAmountMap,
																					Map<Entity,BigDecimal> sellSettlementByEntityAmountMap) {

		List<Entry<Entity,BigDecimal>> buySettlementAmountEntryList = new ArrayList<>(buySettlementByEntityAmountMap.entrySet()); 
		List<Entry<Entity,BigDecimal>> sellSettlementAmountEntryList = new ArrayList<>(sellSettlementByEntityAmountMap.entrySet()); 
		Collections.sort(buySettlementAmountEntryList, reverseSortBySettlementAmountComparator);
		Collections.sort(sellSettlementAmountEntryList, reverseSortBySettlementAmountComparator);

		Pair<List<Entry<Entity,BigDecimal>>, List<Entry<Entity,BigDecimal>>> rankedEntityPair = new Pair<>(buySettlementAmountEntryList,sellSettlementAmountEntryList);
		return rankedEntityPair;
	}


}
