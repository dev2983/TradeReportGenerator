package com.company.report;

import com.company.handler.TradeDataAggregationHandler;

public class TradeReportGenerationService {

	
	private TradeDataAggregationHandler dataAggregationHandler;
	
	public TradeReportGenerationService() {
		super();
		dataAggregationHandler =  new TradeDataAggregationHandler();
	}
	
	public void generateReport(String fileName) {
		// call data ingestion loader to build list of tradeData
		
		//call TradeDataAggregationHandler with list of tradeData
		
		//print report
	}
	
	

	
}
