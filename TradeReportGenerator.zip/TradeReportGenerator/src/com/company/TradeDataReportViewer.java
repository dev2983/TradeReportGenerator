package com.company;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.company.model.Pair;
import com.company.model.TradeReport;
import com.company.util.DateUtils;
import com.company.util.DataConstants.Entity;

public class TradeDataReportViewer {

	
	public void viewReportData(TradeReport tradeReport) {
		System.out.println("-------------------------------------------------------------------------------------------------------------------");
		System.out.println("-------------------------------------------------------------------------------------------------------------------");
		viewAmountsBySettlementDate(tradeReport.getAmountPairBySettlementDateMap());
		System.out.println("-------------------------------------------------------------------------------------------------------------------");
		System.out.println("-------------------------------------------------------------------------------------------------------------------");
		viewEntityByBuySettlementAmount(tradeReport.getBuySettlementByEntityRankedList());
		System.out.println("-------------------------------------------------------------------------------------------------------------------");
		System.out.println("-------------------------------------------------------------------------------------------------------------------");
		viewEntityBySellSettlementAmount(tradeReport.getSellSettlementByEntityRankedList());
		
	}
	
	private void viewEntityByBuySettlementAmount(List<Entry<Entity,BigDecimal>> buySettlementByEntityRankedList) {
		
		System.out.println("Number of entities who have outgoing transaction amounts = "+ buySettlementByEntityRankedList.size());
		System.out.println("Start printing entities with outgoing transaction amounts ");
		
		Entry<Entity,BigDecimal> entry = null;
		for(int i =0;i<buySettlementByEntityRankedList.size();i++) {
			entry = buySettlementByEntityRankedList.get(i);
			System.out.println("");
			System.out.printf("\tRanking of Entity %s is %d with total outgoing amount = %fUSD",entry.getKey().toString(),(i+1),entry.getValue());
			System.out.println("");
		}
		System.out.println("End printing entities with outgoing transaction amounts ");
		
	}
	
	private void viewEntityBySellSettlementAmount(List<Entry<Entity,BigDecimal>> sellSettlementByEntityRankedList) {
		
		System.out.println("Number of entities who have incoming transaction amounts = "+ sellSettlementByEntityRankedList.size());
		System.out.println("Start printing entities with incoming transaction amounts ");
		Entry<Entity,BigDecimal> entry = null;
		for(int i =0;i<sellSettlementByEntityRankedList.size();i++) {
			entry = sellSettlementByEntityRankedList.get(i);
			System.out.println("");
			System.out.printf("\tRanking of Entity %s is %d with total incoming amount = %fUSD ",entry.getKey().toString(),(i+1),entry.getValue());
			System.out.println("");
		}
		System.out.println("");
		System.out.println("End printing entities with incoming transaction amounts ");
		
	}
	
	private void viewAmountsBySettlementDate(Map<LocalDate,Pair<BigDecimal,BigDecimal>> amountPairBySettlementDateMap) {
		
		System.out.println("Number of settlement amounts displayed in USD per day = "+ amountPairBySettlementDateMap.size());
		System.out.println("Start printing settlement amounts in USD per day ");
		
		amountPairBySettlementDateMap.entrySet().forEach( entry -> {
			
			System.out.println("");
			printDatesAndAmounts(entry);
			System.out.println("");
			
		});
		System.out.println("");
		System.out.println("End printing settlement amounts in USD per day ");
	}
	
	private void printDatesAndAmounts(Entry<LocalDate, Pair<BigDecimal, BigDecimal>> entry) {
		
		LocalDate settlementDate = entry.getKey();
		String settlementDateString = DateUtils.formatDate(settlementDate);
		Pair<BigDecimal,BigDecimal> amountPair = entry.getValue();
		if(amountPair.getFirst() == null) {
			System.out.printf("\tNo Buy Amount on Settlement Date %s \n",settlementDateString);
		} 
		else {
			System.out.printf("\tBuy Amount = %f on Settlement Date %s \n",amountPair.getFirst(),settlementDateString);
		}
		if(amountPair.getSecond() == null) {
			System.out.printf("\tNo Sell Amount on Settlement Date %s \n",settlementDateString);
		}
		else {
			System.out.printf("\tSell Amount = %f on Settlement Date %s \n",amountPair.getSecond(),settlementDateString);
		}
	}

}
