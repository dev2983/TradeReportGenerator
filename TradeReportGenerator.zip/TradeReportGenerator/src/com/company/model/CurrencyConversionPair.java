package com.company.model;
import  com.company.util.DataConstants.CurrencyCode;
import static com.company.util.DataConstants.CurrencyCode.USD;
import static com.company.util.DataConstants.CurrencyCode.AED;
import static com.company.util.DataConstants.CurrencyCode.SGD;
import static com.company.util.DataConstants.CurrencyCode.EUR;
import static com.company.util.DataConstants.CurrencyCode.GBP;
import static com.company.util.DataConstants.CurrencyCode.SAR;

public enum CurrencyConversionPair {
	
	USD_SGD(USD,SGD,1.41666d,0.705882d),
	USD_GBP(USD,GBP,0.891289d,1.2205d),
	USD_EUR(USD,EUR,1.0791565,0.9264d),
	USD_SAR(USD,SAR,1.555566d,0.6428d),
	USD_AED(USD,AED,5.44,0.1838d);
	
	private CurrencyCode currencyCodeOne;
	private CurrencyCode currencyCodeTwo;
	private double conversionRatio;//currencyCodeOne/currencyCodeTwo
	private double invertedConversionRatio;//currencyCodetwo/currencyCodeOne
	
	
	CurrencyConversionPair(CurrencyCode currencyCodeOne,CurrencyCode currencyCodeTwo,double conversionRatio,double invertedConversionRatio) {
		this.currencyCodeOne = currencyCodeOne;
		this.currencyCodeTwo = currencyCodeTwo;
		this.conversionRatio = conversionRatio;
		this.invertedConversionRatio = invertedConversionRatio;
	}

	public CurrencyCode getCurrencyCodeOne() {
		return currencyCodeOne;
	}

	public CurrencyCode getCurrencyCodeTwo() {
		return currencyCodeTwo;
	}

	public double getConversionRatio() {
		return conversionRatio;
	}

	public double getInvertedConversionRatio() {
		return invertedConversionRatio;
	}
	
	public static double[] fetchConversionRatios(CurrencyCode currencyCodeOne,CurrencyCode currencyCodeTwo) {
		for(CurrencyConversionPair pair : CurrencyConversionPair.values()) {
			if(pair.getCurrencyCodeOne() == currencyCodeOne && pair.getCurrencyCodeTwo() == currencyCodeTwo) {
				return new double[]{pair.getConversionRatio(),pair.getInvertedConversionRatio()};
			}
		}
		return null;
	}
	
	
}
