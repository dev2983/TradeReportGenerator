package com.company.model;
import java.math.BigDecimal;
import java.time.LocalDate;

import com.company.util.DataConstants.CurrencyCode;
import com.company.util.DataConstants.Entity;
import com.company.util.DataConstants.TransactionFlag;
import com.company.util.DerivedDataCalculator;

public class TradeData {
	
	private final Entity entity;
	private final TransactionFlag transactionFlag;
	private final BigDecimal agreedFx;
	private final CurrencyCode currencyCode;
	private final LocalDate instructionDate;
	private final LocalDate settlementDate;
	private final long units;
	private final BigDecimal perUnitPrice;
	
	private DerivedTradeData derivedTradeData;
	
	public TradeData(Builder builder) {
		this.entity =  builder.entity;
		this.transactionFlag = builder.transactionFlag;
		this.agreedFx = builder.agreedFx;
		this.currencyCode = builder.currencyCode;
		this.instructionDate = builder.instructionDate;
		this.settlementDate = builder.settlementDate;
		this.units = builder.units;
		this.perUnitPrice = builder.perUnitPrice;
	}
	
	public Entity getEntity() {
		return entity;
	}
	
	public TransactionFlag getTransactionFlag() {
		return transactionFlag;
	}


	public BigDecimal getAgreedFx() {
		return agreedFx;
	}


	public CurrencyCode getCurrencyCode() {
		return currencyCode;
	}


	public LocalDate getInstructionDate() {
		return instructionDate;
	}


	public LocalDate getSettlementDate() {
		return settlementDate;
	}


	public long getUnits() {
		return units;
	}


	public BigDecimal getPerUnitPrice() {
		return perUnitPrice;
	}

	public DerivedTradeData getDerivedTradeData() {
		if(derivedTradeData ==  null) {
			computeDerivedTradeData();
		}
		return derivedTradeData;
	}
	
	private void computeDerivedTradeData() {
		//call computation of derived data
		this.derivedTradeData = DerivedDataCalculator.computeDerivedData(this);
	}
	
	public static class Builder {
		
		private  Entity entity;
		private TransactionFlag transactionFlag;
		private BigDecimal agreedFx;
		private CurrencyCode currencyCode;
		private LocalDate instructionDate;
		private LocalDate settlementDate;
		private long units;
		private BigDecimal perUnitPrice;
		
		public TransactionFlag getTransactionFlag() {
			return transactionFlag;
		}
		public BigDecimal getAgreedFx() {
			return agreedFx;
		}
		public CurrencyCode getCurrencyCode() {
			return currencyCode;
		}
		public LocalDate getInstructionDate() {
			return instructionDate;
		}
		public LocalDate getSettlementDate() {
			return settlementDate;
		}
		public long getUnits() {
			return units;
		}
		public BigDecimal getPerUnitPrice() {
			return perUnitPrice;
		}
		
		public Entity getEntity() {
			return entity;
		}
		
		public Builder entity(Entity entity) {
			this.entity = entity;
			return this;
			
		}
		
		public Builder transactionFlag(TransactionFlag transactionFlag) {
			this.transactionFlag = transactionFlag;
			return this;
			
		}
		public Builder agreedFx(BigDecimal agreedFx) {
			this.agreedFx = agreedFx;
			return this;
		}
		public Builder currencyCode(CurrencyCode currencyCode) {
			this.currencyCode = currencyCode;
			return this;
		}
		public Builder instructionDate(LocalDate instructionDate) {
			this.instructionDate = instructionDate;
			return this;
		}
		public Builder settlementDate(LocalDate settlementDate) {
			this.settlementDate = settlementDate;
			return this;
		}
		public Builder units(long units) {
			this.units = units;
			return this;
		}
		public Builder perUnitPrice(BigDecimal perUnitPrice) {
			this.perUnitPrice = perUnitPrice;
			return this;
		}
		
		public TradeData build() {
			return new TradeData(this);
		}
		
	}
	
	public String toString() {
		
		StringBuilder sb = new StringBuilder();
		sb.append("{").append(entity).append(",").
		append(transactionFlag).append(",").
		append(agreedFx).append(",").
		append(currencyCode).append(",").
		append(instructionDate).append(",").
		append(settlementDate).append(",").
		append(perUnitPrice).append(",").
		append(units).append("}");
		return sb.toString();
	}
}
