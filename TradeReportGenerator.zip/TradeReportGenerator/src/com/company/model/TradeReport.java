package com.company.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.company.util.DataConstants.Entity;

public class TradeReport {
	
	private final Map<LocalDate,Pair<BigDecimal,BigDecimal>> amountPairBySettlementDateMap;
	
	private final List<Entry<Entity,BigDecimal>> buySettlementByEntityRankedList;
	private final List<Entry<Entity,BigDecimal>> sellSettlementByEntityRankedList;
	
	public TradeReport(Map<LocalDate, Pair<BigDecimal, BigDecimal>> amountPairBySettlementDateMap,
			Pair<List<Entry<Entity,BigDecimal>>, List<Entry<Entity,BigDecimal>>> rankedEntityPair) {
		this.amountPairBySettlementDateMap = amountPairBySettlementDateMap;
		this.buySettlementByEntityRankedList = rankedEntityPair.getFirst();
		this.sellSettlementByEntityRankedList = rankedEntityPair.getSecond();
	}

	public Map<LocalDate, Pair<BigDecimal, BigDecimal>> getAmountPairBySettlementDateMap() {
		return amountPairBySettlementDateMap;
	}

	public List<Entry<Entity, BigDecimal>> getBuySettlementByEntityRankedList() {
		return buySettlementByEntityRankedList;
	}

	public List<Entry<Entity, BigDecimal>> getSellSettlementByEntityRankedList() {
		return sellSettlementByEntityRankedList;
	}
	
	

}
