package com.company.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class DerivedTradeData {

	private final LocalDate amendedSettlementDate;
	private final BigDecimal convertedSettlementAmount;

	public DerivedTradeData(LocalDate amendedSettlementDate, BigDecimal convertedSettlementAmount) {
		super();
		this.amendedSettlementDate = amendedSettlementDate;
		this.convertedSettlementAmount = convertedSettlementAmount;
	}
	public LocalDate getAmendedSettlementDate() {
		return amendedSettlementDate;
	}
	public BigDecimal getConvertedSettlementAmount() {
		return convertedSettlementAmount;
	}


}
