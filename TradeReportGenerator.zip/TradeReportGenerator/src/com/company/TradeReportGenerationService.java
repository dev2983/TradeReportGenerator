package com.company;

import java.util.List;

import com.company.data.CsvTradeDataReader;
import com.company.handler.TradeDataAggregationHandler;
import com.company.model.TradeData;
import com.company.model.TradeReport;

public class TradeReportGenerationService {
	
	private CsvTradeDataReader csvTradeDataReader;
	private TradeDataAggregationHandler dataAggregationHandler;
	private TradeDataReportViewer tradeDataReportViewer;
	
	public TradeReportGenerationService() {
		this.csvTradeDataReader = new CsvTradeDataReader();
		this.dataAggregationHandler =  new TradeDataAggregationHandler();
		this.tradeDataReportViewer = new TradeDataReportViewer();
	}
	
	public void generateReport(String fileName) {
		
		//call the data reader
		List<TradeData> tradeDataList = csvTradeDataReader.loadTradeDataList(fileName);
		System.out.println("Number of trade records to be processed = "+tradeDataList.size());
		long startTime = System.currentTimeMillis();
		//Call the aggregation data handler to build report data
		TradeReport tradeReport = dataAggregationHandler.buildReportData(tradeDataList);
		//print the report data
		tradeDataReportViewer.viewReportData(tradeReport);
		long endTime = System.currentTimeMillis();
		System.out.println("Total time to generate the report = "+(endTime-startTime) + "ms");
	}
	
}
