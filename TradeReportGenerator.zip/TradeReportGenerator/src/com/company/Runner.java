package com.company;

public class Runner {
	
	public static void main(String[] args) {
		
		String fileName = null;
		if(args.length == 0) {
			fileName = "inputFiles//tradeData_BUY_AND_SELL_200000.csv";//default if no program argument is passed for file name path
		}
		else {
			fileName  = args[0];
		}
		//Sample input files present at inputFiles folder like inputFiles//tradeData_BUY_AND_SELL_200000.csv,inputFiles//tradeData_BUY_100000.csv
		execute(fileName);
	}
	
	private static void execute(String fileName) {
		TradeReportGenerationService tradeReportGenerationService = new TradeReportGenerationService();
		tradeReportGenerationService.generateReport(fileName);
	}

}
