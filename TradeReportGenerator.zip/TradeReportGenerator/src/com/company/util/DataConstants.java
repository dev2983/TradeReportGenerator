package com.company.util;

import java.time.DayOfWeek;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public interface DataConstants {
	
	enum TransactionFlag {
		BUY("B"),SELL("S");

		private final String code;	
		TransactionFlag(String code) {
			this.code = code;
		}

		public String getCode() {
			return code;
		}
		
		private static Map<String,TransactionFlag> codeToTransactionFlagMap = new HashMap<>();
		
		static{
			for(TransactionFlag flag : TransactionFlag.values()) {
				codeToTransactionFlagMap.put(flag.code,flag);
			}
		}
		
		public static TransactionFlag getTransactionFlagByCode(String code) {
			if(code == null) { return null;}
			return codeToTransactionFlagMap.get(code);
		}

	};
	
	enum CurrencyCode {
		SGD,USD,GBP,SAR,AED,INR,EUR,YEN,AUD;
	}
	
	enum Entity {
		
		MORGAN_STANLEY("MS"),
		UBS("UBS"),
		HSBC("HSBC"),
		CITICORP("CITI"),
		BANK_OF_AMERICA("BOFA"),
		CARGILL("CGL");
		
		Entity(String code) {
			this.code = code;
		}
		
		private final String code;
		
		public String getCode() {
			return code;
		}
		
		private static Map<String,Entity> codeToEntityMap = new HashMap<>();
		
		static{
			for(Entity entity : Entity.values()) {
				codeToEntityMap.put(entity.code,entity);
			}
		}
		
		public static Entity getEntityByCode(String code) {
			if(code == null) { return null;}
			return codeToEntityMap.get(code);
		}
	}
	
	String DATE_PATTERN = "dd MMM yyyy";
	List<DayOfWeek> EXCEPTION_HOLIDAY_LIST = Arrays.asList(DayOfWeek.FRIDAY,DayOfWeek.SATURDAY);
	List<DayOfWeek> GENERAL_HOLIDAY_LIST = Arrays.asList(DayOfWeek.SATURDAY,DayOfWeek.SUNDAY);
	List<CurrencyCode> CURRENCY_CODES_FOR_EXCEPTION_HOLIDAY_LIST = Arrays.asList(CurrencyCode.AED,CurrencyCode.SAR);
	CurrencyCode DEFAULT_CURRENCY_CONVERSION_CODE = CurrencyCode.USD;
	
}
