package com.company.util;
import static com.company.util.DataConstants.CURRENCY_CODES_FOR_EXCEPTION_HOLIDAY_LIST;
import static com.company.util.DataConstants.DATE_PATTERN;
import static com.company.util.DataConstants.EXCEPTION_HOLIDAY_LIST;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import com.company.util.DataConstants.CurrencyCode;

public class DateUtils {
	
	private static DateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN);
	
	public static LocalDate parseDateString(String dateString) {
		if(dateString == null || dateString.isEmpty()) { return null;}
		LocalDate date1 = null;
		date1 = LocalDate.parse(dateString,DateTimeFormatter.ofPattern(DATE_PATTERN));
		return date1;
	}
	
	public static Date parseDateString1(String dateString) {
		if(dateString == null || dateString.isEmpty()) { return null;}
		Date date = null;
		try {
			date = dateFormat.parse(dateString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	public static String formatDate(LocalDate date) {
		if(date ==  null ) { return null; }
		return date.format(DateTimeFormatter.ofPattern(DATE_PATTERN));
	}
	
}
