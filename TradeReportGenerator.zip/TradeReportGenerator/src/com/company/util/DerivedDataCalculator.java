package com.company.util;

import static com.company.util.DataConstants.CURRENCY_CODES_FOR_EXCEPTION_HOLIDAY_LIST;
import static com.company.util.DataConstants.DEFAULT_CURRENCY_CONVERSION_CODE;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;

import com.company.model.CurrencyConversionPair;
import com.company.model.DerivedTradeData;
import com.company.model.TradeData;
import com.company.util.DataConstants.CurrencyCode;

public class DerivedDataCalculator {
	
	public static DerivedTradeData computeDerivedData(TradeData data) {
		
		LocalDate amendedSettlementDate = amendDateIfHoliday(data.getSettlementDate(), data.getCurrencyCode());
		DerivedTradeData derivedTradeData = new DerivedTradeData(amendedSettlementDate, calculateSettlementAmountInConverionCurrency(data));
		return derivedTradeData;
	}
	
	public  static LocalDate amendDateIfHoliday(LocalDate date,CurrencyCode currencyCode) {
		if(date == null || currencyCode == null) { return null; }
		LocalDate amendedDate = date;
		int daysToAdd = 0;
		if( CURRENCY_CODES_FOR_EXCEPTION_HOLIDAY_LIST.contains(currencyCode) ) {
			if(DayOfWeek.FRIDAY.equals(date.getDayOfWeek())) {
				daysToAdd = 2;
			}
			else if(DayOfWeek.SATURDAY.equals(date.getDayOfWeek())) {
				daysToAdd = 1;
			}
		}
		else {
			if(DayOfWeek.SATURDAY.equals(date.getDayOfWeek())) {
				daysToAdd = 2;
			}
			else if(DayOfWeek.SUNDAY.equals(date.getDayOfWeek())) {
				daysToAdd = 1;
			}
		}
		amendedDate = amendedDate.plusDays(daysToAdd);
		return amendedDate;
	}
	
	public static BigDecimal calculateSettlementAmountInConverionCurrency(TradeData data) {
		double converionRatio =  CurrencyConversionPair.fetchConversionRatios(DEFAULT_CURRENCY_CONVERSION_CODE, data.getCurrencyCode())[0];
		BigDecimal tradedAmount = BigDecimal.valueOf(data.getUnits() * converionRatio).
				multiply(data.getAgreedFx()).
				multiply(data.getPerUnitPrice());
		return tradedAmount;
		
	}
}
